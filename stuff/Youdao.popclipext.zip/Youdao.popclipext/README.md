#Youdao Dictionary (Web Version) PopClip Extension
##Introduction
Youdao Dictionary is a web and desktop dictionary app popular in China, created by NetEase.

##Credit
Extension and icon by Jacob

Cantact me: blog.thatboy.me